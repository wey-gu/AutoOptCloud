## API reference

### command line

```bash
$ pip install dashboard_be.tar.gz
$ dashb

Command-line interface to the Dashboard backend.

Sub Commands:
  backend           Init a backend instance
  watchdog          Run data.csv watchdog

```


## build

```bash
$ pwd
~/ML-opt-Cloud/

$ ./build.sh

```
