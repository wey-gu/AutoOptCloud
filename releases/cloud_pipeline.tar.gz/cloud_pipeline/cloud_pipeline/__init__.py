from .handler.cloud_pipeline import CloudPipelineBase


class CloudPipeline(CloudPipelineBase):
    """
    cloud pipeline
    """
    pass
